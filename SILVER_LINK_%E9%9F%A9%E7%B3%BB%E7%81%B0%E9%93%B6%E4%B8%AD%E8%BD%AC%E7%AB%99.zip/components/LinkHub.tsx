 'use client';
import {useEffect,useMemo,useState} from 'react';
import {createClient} from '@/lib/supabase';
import {ArrowUpRight,Search,Star,ShieldAlert,Settings2,Heart,ExternalLink} from 'lucide-react';
type Site={id:string;name:string;url:string;description:string;category_id:string;is_pinned:boolean};
type Cat={id:string,name:string,slug:string};
export default function LinkHub(){
 const supabase=createClient();
 const [sites,setSites]=useState<Site[]>([]),[cats,setCats]=useState<Cat[]>([]),[settings,setSettings]=useState<any>({title:'SILVER LINK',subtitle:'把喜欢的链接，收藏成一片温柔星河。',background:'#eef0f4',particles:true}),[warnings,setWarnings]=useState<any[]>([]);
 const [query,setQuery]=useState(''),[active,setActive]=useState('all'),[spark,setSpark]=useState(true);
 useEffect(()=>{(async()=>{
  const [s,c,st,w]=await Promise.all([supabase.from('sites').select('*').order('created_at',{ascending:false}),supabase.from('categories').select('*').order('sort_order'),supabase.from('site_settings').select('*').eq('id',1).maybeSingle(),supabase.from('warnings').select('*').order('created_at',{ascending:false})]);
  if(s.data)setSites(s.data);if(c.data)setCats(c.data);if(st.data)setSettings(st.data);if(w.data)setWarnings(w.data);
  setSpark(st.data?.particles??true);
 })()},[]);
 const filtered=useMemo(()=>sites.filter(x=>(active==='all'||x.category_id===active)&&`${x.name} ${x.description}`.toLowerCase().includes(query.toLowerCase())),[sites,active,query]);
 return <main className="shell" style={{background:settings.background||'#eef0f4'}}>
  {spark&&settings.particles!==false&&<div className="sparkles" aria-hidden="true">{Array.from({length:24},(_,i)=><i key={i} style={{left:`${(i*37)%100}%`,animationDelay:`-${(i%9)*1.4}s`,animationDuration:`${8+(i%7)}s`}}>✦</i>)}</div>}
  <header className="topbar"><div className="brand"><span className="brandMark">✧</span><span>SILVER <b>LINK</b></span></div><a className="adminLink" href="/login"><Settings2 size={15}/> 管理入口</a></header>
  <section className="hero"><div className="eyebrow">✦ MY LITTLE LINK ARCHIVE ✦</div><h1>{settings.title||'SILVER LINK'}<span> ✧</span></h1><p>{settings.subtitle||'把喜欢的链接，收藏成一片温柔星河。'}</p><div className="heroLine"/></section>
  <div className="tools"><label className="search"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="搜索站点 / 关键词…"/></label><button className={`toggle ${spark?'on':''}`} onClick={()=>setSpark(!spark)}><Star size={14}/>{spark?'星星 ON':'星星 OFF'}</button></div>
  <nav className="categories"><button className={active==='all'?'active':''} onClick={()=>setActive('all')}>全部链接 <small>{sites.length}</small></button>{cats.map(c=><button key={c.id} className={active===c.id?'active':''} onClick={()=>setActive(c.id)}>{c.name}</button>)}</nav>
  <section className="cards">{filtered.map((s,i)=><a className="siteCard" href={s.url} target="_blank" rel="noopener noreferrer" key={s.id}><div className="cardTop"><span className="number">{String(i+1).padStart(2,'0')}</span><ArrowUpRight size={16}/></div><h3>{s.name}</h3><p>{s.description||'收藏一枚温柔的链接 ✧'}</p><div className="cardFoot"><span>{cats.find(c=>c.id===s.category_id)?.name||'未分类'}</span><span className="dot"/></div></a>)}
   {!filtered.length&&<div className="empty">还没有找到相关链接 · 试试其他关键词吧 ✧</div>}
  </section>
  <section className="warningBox"><div className="warningTitle"><ShieldAlert size={17}/> <span>避雷 / CAUTION</span><small>温柔提醒，理性收藏</small></div>{warnings.length?warnings.map(w=><div className="warningItem" key={w.id}><b>{w.title}</b><p>{w.content}</p></div>):<p className="muted">暂无避雷内容，管理员可以在后台添加。</p>}</section>
  <footer>MADE WITH <Heart size={12} fill="currentColor"/> IN SILVER TONE <span>© SILVER LINK</span></footer>
 </main>
}