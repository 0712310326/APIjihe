import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'SILVER LINK — Link Archive', description: 'A soft silver link archive' };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}