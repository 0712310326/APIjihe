-- SILVER LINK schema. Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.admins (
 user_id uuid primary key references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.categories (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 slug text not null unique,
 sort_order int not null default 0,
 created_at timestamptz not null default now()
);
create table if not exists public.sites (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 url text not null,
 description text default '',
 category_id uuid references public.categories(id) on delete set null,
 is_pinned boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.warnings (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 content text not null default '',
 created_at timestamptz not null default now()
);
create table if not exists public.site_settings (
 id int primary key default 1 check(id=1),
 title text not null default 'SILVER LINK',
 subtitle text not null default '把喜欢的链接，收藏成一片温柔星河。',
 background text not null default '#eef0f4',
 particles boolean not null default true,
 updated_at timestamptz not null default now()
);
insert into public.site_settings(id) values(1) on conflict do nothing;
insert into public.categories(name,slug,sort_order) values
 ('常用','common',1),('灵感','inspiration',2),('工具','tools',3),('其他','other',4)
on conflict(slug) do nothing;
alter table public.admins enable row level security;
alter table public.categories enable row level security;
alter table public.sites enable row level security;
alter table public.warnings enable row level security;
alter table public.site_settings enable row level security;
-- Public read
create policy "public read categories" on public.categories for select using(true);
create policy "public read sites" on public.sites for select using(true);
create policy "public read warnings" on public.warnings for select using(true);
create policy "public read settings" on public.site_settings for select using(true);
-- Admin helper (security definer avoids recursive RLS)
create or replace function public.is_silver_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.admins where user_id=auth.uid()) $$;
-- Admin-only write
create policy "admins manage categories" on public.categories for all using(public.is_silver_admin()) with check(public.is_silver_admin());
create policy "admins manage sites" on public.sites for all using(public.is_silver_admin()) with check(public.is_silver_admin());
create policy "admins manage warnings" on public.warnings for all using(public.is_silver_admin()) with check(public.is_silver_admin());
create policy "admins manage settings" on public.site_settings for all using(public.is_silver_admin()) with check(public.is_silver_admin());
create policy "admins read admins" on public.admins for select using(public.is_silver_admin());
-- Add your admin after creating an account in Authentication > Users.
-- Replace YOUR_AUTH_USER_UUID below with that user's UUID, then run:
-- insert into public.admins(user_id) values ('YOUR_AUTH_USER_UUID');
