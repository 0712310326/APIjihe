# SILVER LINK · 韩系灰银中转站

Next.js + Supabase 的链接收藏网站。访客可浏览/跳转；只有 `admins` 表授权用户可登录管理后台并编辑。

## 1. 本地启动
```bash
npm install
cp .env.example .env.local
# 填入 Supabase Project URL 和 Publishable Key
npm run dev
```

## 2. 初始化数据库
1. 打开 Supabase 项目 → SQL Editor。
2. 执行 `supabase/schema.sql` 全部内容。
3. Authentication → Users → Add user，创建管理员邮箱/密码。
4. 在 Users 中复制该用户 UUID。
5. SQL Editor 执行（替换 UUID）：
```sql
insert into public.admins(user_id) values ('你的Auth用户UUID');
```
6. 网站 `/login` 登录后进入 `/admin`。

## 3. 部署到 Vercel
1. 将项目上传到 GitHub。
2. Vercel Import 项目。
3. Settings → Environment Variables 添加：
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
4. Deploy。

## 安全说明
- 浏览器只使用 Supabase Publishable Key（可公开）。
- 不要把 `service_role` / Secret Key 放到前端、GitHub 或 Vercel 的 `NEXT_PUBLIC_` 环境变量。
- 数据写权限通过 Supabase RLS 和 `admins` 表校验；不是单纯隐藏按钮。
- SQL 文件包含公开读取、管理员写入策略。
- 登录账号必须被加入 `public.admins`，否则后台会显示无权限。
- `site_settings` 当前提供标题、副标题、背景色和粒子默认开关；页面内粒子开关为访客临时开关。

## 页面
- `/` 访客主页
- `/login` 管理员登录
- `/admin` 管理后台（站点、分类、避雷、网页设置）
